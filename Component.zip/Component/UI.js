import React, { useState } from 'react'
import { data } from './DataBase'
import List from './List'
import './List.style.css'

function UI() {

    const ar = []

    const looper = (arr) => {
        arr.map((elem, index) => {
            ar.push(<List keys={elem[0]} values={elem[1]} id={index} />)
            console.log(elem[0], elem[1])
        })
        return ar;

    }


    return (
        <div className='listDivContainer'>
            {looper(Object.entries(data))}

        </div>
    )
}


export default UI
