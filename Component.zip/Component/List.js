import React, { useState } from 'react'
import './List.style.css'
let selectedDivData = { value: '', id: 0 };
function List({ keys, values, id }) {
    const [toggle, setToggle] = useState(false)

    const handleToggle = () => {
        toggle ? setToggle(false) : setToggle(true);
    }

    const handleOnclick = (id) => {
        handleToggle();
        selectedDivData.id = id
    }

    const handleOnchange = (e) => {
        selectedDivData.value = e.target.value;
    }

    const handleOnInputclick = () => {
        handleToggle();
        console.log(selectedDivData.id);
        console.log(selectedDivData.value);
        document.getElementById(selectedDivData.id).innerText = selectedDivData.value;

    }

    return (
        <div className='parentDiv'>
            <div className='childDiv' >{keys}</div>
            <div className='childDiv' id={id} onClick={(e) => handleOnclick(e.target.id)}>{values}</div >
            {toggle && (<div>
                <input type='text' onChange={(e) => handleOnchange(e)} />
                <button onClick={handleOnInputclick}>add</button>
            </div>)}
        </div>
    )
}


export default List

